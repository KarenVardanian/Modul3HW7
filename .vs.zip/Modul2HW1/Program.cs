﻿using System;
using System.IO;

namespace Modul2HW1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string p = System.IO.Directory.GetCurrentDirectory();
            Directory.CreateDirectory("Backup");

            Console.WriteLine(p);
            var starter = new Starter();
            starter.BackUpHandler += starter.Run;
            int n = starter.GetN();
            starter.BackUpHandler.Invoke(n);
         }
    }
}
