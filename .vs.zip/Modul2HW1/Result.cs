﻿namespace Modul2HW1
{
    public class Result
    {
        public bool Status { get; set; }
        public string ErrorMessage { get; set; }
    }
}
