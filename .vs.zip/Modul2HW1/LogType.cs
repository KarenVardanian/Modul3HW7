﻿namespace Modul2HW1
{
    public enum LogType
    {
        Info,
        Warning,
        Error
    }
}
